
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const mongoose = require("mongoose");
const { DB_URL } = require("./config/db.config");


const app = express();

// CORS configuration
app.use(cors());

// Body parser middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// MongoDB connection
mongoose
  .connect(DB_URL)
  .then(() => {
    console.log("Connected to the database!");
  })
  .catch((err) => {
    console.error("Cannot connect to the database!", err);
    process.exit(1);
  });

// Root route
app.get("/", (req, res) => {
  res.json({ 
    message: "Welcome to Upgrad Movie booking application development." 
  });
});

// API routes
const movieRoutes = require("./routes/movie.routes");
const artistRoutes = require("./routes/artist.routes");
const genreRoutes = require("./routes/genre.routes");
const userRoutes = require("./routes/user.routes");

app.use("/api/movies", movieRoutes);
app.use("/api/artists", artistRoutes);
app.use("/api/genres", genreRoutes);
app.use("/api/auth", userRoutes);

// Set port and listen for requests
const PORT = process.env.PORT || 8085;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}.`);
});

module.exports = app;
