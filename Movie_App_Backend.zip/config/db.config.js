/*require('dotenv').config();
const mongoose = require('mongoose');

MONGODB_URI='mongodb+srv://arpangiri:test%4012345@moviebooking.qat9e1w.mongodb.net/?appName=MovieBooking'

const connectDB = async () => {
    try {
        await mongoose.connect(MONGODB_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log('MongoDB connected successfully');
    } catch (error) {
        console.error('MongoDB connection error:', error);
        process.exit(1);
    }
};

module.exports = connectDB;*/
require('dotenv').config();

const DB_URL = 'mongodb+srv://arpangiri:test%4012345@moviebooking.qat9e1w.mongodb.net/moviebooking';

module.exports = { DB_URL };

