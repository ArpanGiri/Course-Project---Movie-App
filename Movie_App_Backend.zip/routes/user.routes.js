const express = require("express");
const router = express.Router();
const userController = require("../controllers/user.controller");

// POST signup
router.post("/signup", userController.signUp);

// POST login
router.post("/login", userController.login);

// POST logout
router.post("/logout/:uuid", userController.logout);

// GET coupon code
router.get("/coupons/:couponCode", userController.getCouponCode);

// POST book show
router.post("/bookings", userController.bookShow);

module.exports = router;
