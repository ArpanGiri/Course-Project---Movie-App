const User = require("../models/user.model");
const UuidTokenGenerator = require("uuid-token-generator");
const { uuid } = require("uuidv4");
const b2a = require("b2a");

const tokgen = new UuidTokenGenerator();

// User Signup
exports.signUp = async (req, res) => {
  try {
    const { email, first_name, last_name, username, contact, password } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        message: "User already exists with this email"
      });
    }

    // Get the highest userid and increment
    const lastUser = await User.findOne().sort({ userid: -1 });
    const newUserId = lastUser ? lastUser.userid + 1 : 1;

    // Create new user
    const user = new User({
      userid: newUserId,
      email,
      first_name,
      last_name,
      username: username || `${first_name}${last_name}`,
      contact,
      password,
      role: "user",
      isLoggedIn: false,
      uuid: "",
      accesstoken: "",
      coupens: [],
      bookingRequests: []
    });

    const savedUser = await user.save();
    
    res.status(201).json({
      message: "User registered successfully",
      userid: savedUser.userid,
      email: savedUser.email
    });
  } catch (error) {
    res.status(500).json({
      message: error.message || "Some error occurred while registering the user."
    });
  }
};

// User Login
exports.login = async (req, res) => {
  try {
    // Extract authorization header
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith("Basic ")) {
      return res.status(401).json({
        message: "Missing or invalid authorization header"
      });
    }

    // Decode base64 credentials
    const base64Credentials = authHeader.split(" ")[1];
    const credentials = b2a.atob(base64Credentials);
    const [username, password] = credentials.split(":");

    // Find user by username and password
    const user = await User.findOne({ username, password });

    if (!user) {
      return res.status(401).json({
        message: "Invalid credentials"
      });
    }

    // Generate UUID and access token
    const userUuid = uuid();
    const accessToken = tokgen.generate();

    // Update user with login details
    user.isLoggedIn = true;
    user.uuid = userUuid;
    user.accesstoken = accessToken;
    await user.save();

    res.status(200).json({
      message: "Login successful",
      userid: user.userid,
      uuid: userUuid,
      accesstoken: accessToken,
      email: user.email,
      first_name: user.first_name,
      last_name: user.last_name
    });
  } catch (error) {
    res.status(500).json({
      message: error.message || "Some error occurred while logging in."
    });
  }
};

// User Logout
exports.logout = async (req, res) => {
  try {
    const { uuid } = req.params;

    if (!uuid) {
      return res.status(400).json({
        message: "UUID is required"
      });
    }

    // Find user by UUID
    const user = await User.findOne({ uuid });

    if (!user) {
      return res.status(404).json({
        message: "User not found"
      });
    }

    // Update user logout status
    user.isLoggedIn = false;
    user.uuid = "";
    user.accesstoken = "";
    await user.save();

    res.status(200).json({
      message: "Logout successful"
    });
  } catch (error) {
    res.status(500).json({
      message: error.message || "Some error occurred while logging out."
    });
  }
};

// Get Coupon Code
exports.getCouponCode = async (req, res) => {
  try {
    const { couponCode } = req.params;
    const { uuid } = req.query;

    // Verify user is logged in
    const user = await User.findOne({ uuid, isLoggedIn: true });

    if (!user) {
      return res.status(401).json({
        message: "Please login to access coupons"
      });
    }

    // Find the coupon in user's coupons
    const coupon = user.coupens.find(c => c.id === parseInt(couponCode));

    if (!coupon) {
      return res.status(404).json({
        message: "Coupon not found"
      });
    }

    res.status(200).json(coupon);
  } catch (error) {
    res.status(500).json({
      message: error.message || "Some error occurred while retrieving coupon."
    });
  }
};

// Book Show
exports.bookShow = async (req, res) => {
  try {
    const { uuid } = req.query;
    const { coupon_code, show_id, tickets } = req.body;

    // Verify user is logged in
    const user = await User.findOne({ uuid, isLoggedIn: true });

    if (!user) {
      return res.status(401).json({
        message: "Please login to book a show"
      });
    }

    // Generate reference number
    const reference_number = Math.floor(10000 + Math.random() * 90000);

    // Create booking request
    const bookingRequest = {
      reference_number,
      coupon_code: coupon_code || 0,
      show_id,
      tickets
    };

    // Add booking to user's booking requests
    user.bookingRequests.push(bookingRequest);
    await user.save();

    res.status(201).json({
      message: "Booking successful",
      reference_number,
      show_id,
      tickets
    });
  } catch (error) {
    res.status(500).json({
      message: error.message || "Some error occurred while booking the show."
    });
  }
};
