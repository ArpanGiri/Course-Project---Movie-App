const mongoose = require("mongoose");

const couponSchema = new mongoose.Schema({
  id: Number,
  discountValue: Number
});

const bookingRequestSchema = new mongoose.Schema({
  reference_number: Number,
  coupon_code: Number,
  show_id: Number,
  tickets: Array
});

const userSchema = new mongoose.Schema({
  userid: {
    type: Number,
    required: true,
    unique: true
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  first_name: {
    type: String,
    required: true
  },
  last_name: {
    type: String,
    required: true
  },
  username: {
    type: String,
    required: true
  },
  contact: {
    type: String,
    required: true
  },
  password: {
    type: String,
    required: true
  },
  role: {
    type: String,
    default: "user"
  },
  isLoggedIn: {
    type: Boolean,
    default: false
  },
  uuid: {
    type: String,
    default: ""
  },
  accesstoken: {
    type: String,
    default: ""
  },
  coupens: [couponSchema],
  bookingRequests: [bookingRequestSchema]
}, {
  timestamps: true
});

module.exports = mongoose.model("User", userSchema, "users");
