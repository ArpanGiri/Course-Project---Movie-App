const mongoose = require("mongoose");

const showSchema = new mongoose.Schema({
  id: Number,
  theatre: {
    name: String,
    city: String
  },
  language: String,
  show_timing: String,
  available_seats: String,
  unit_price: Number
});

const movieSchema = new mongoose.Schema({
  movieid: {
    type: Number,
    required: true,
    unique: true
  },
  title: {
    type: String,
    required: true
  },
  published: {
    type: Boolean,
    default: false
  },
  released: {
    type: Boolean,
    default: false
  },
  poster_url: {
    type: String,
    required: true
  },
  release_date: {
    type: String,
    required: true
  },
  publish_date: {
    type: String,
    required: true
  },
  artists: {
    type: Array,
    default: []
  },
  genres: {
    type: Array,
    default: []
  },
  duration: {
    type: Number,
    required: true
  },
  critic_rating: {
    type: Number,
    required: true
  },
  trailer_url: {
    type: String,
    required: true
  },
  wiki_url: {
    type: String,
    required: true
  },
  story_line: {
    type: String,
    required: true
  },
  shows: [showSchema]
}, {
  timestamps: true
});

module.exports = mongoose.model("Movie", movieSchema, "movies");
