const mongoose = require("mongoose");

module.exports = {
  mongoose,
  Artist: require("./artist.model"),
  Genre: require("./genre.model"),
  Movie: require("./movie.model"),
  User: require("./user.model")
};
