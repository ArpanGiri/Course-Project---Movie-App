const Movie = require("../models/movie.model");

// Find all movies with optional filters
exports.findAllMovies = async (req, res) => {
  try {
    const { status, title, genres, artists, start_date, end_date } = req.query;
    let filter = {};

    // Filter by status (PUBLISHED or RELEASED)
    if (status) {
      if (status.toUpperCase() === "PUBLISHED") {
        filter.published = true;
      } else if (status.toUpperCase() === "RELEASED") {
        filter.released = true;
      }
    }

    // Filter by title
    if (title) {
      filter.title = { $regex: title, $options: "i" };
    }

    // Filter by genres
    if (genres) {
      filter.genres = { $in: genres.split(",") };
    }

    // Filter by artists
    if (artists) {
      const artistNames = artists.split(",");
      filter.$or = artistNames.map(name => ({
        "artists.first_name": { $regex: name, $options: "i" }
      }));
    }

    // Filter by date range
    if (start_date && end_date) {
      filter.release_date = {
        $gte: start_date,
        $lte: end_date
      };
    }

    const movies = await Movie.find(filter);
    res.status(200).json(movies);
  } catch (error) {
    res.status(500).json({
      message: error.message || "Some error occurred while retrieving movies."
    });
  }
};

// Find a single movie by ID
exports.findOne = async (req, res) => {
  try {
    const movieId = parseInt(req.params.movieId);
    const movie = await Movie.findOne({ movieid: movieId });

    if (!movie) {
      return res.status(404).json({
        message: `Movie not found with id ${movieId}`
      });
    }

    res.status(200).json(movie);
  } catch (error) {
    res.status(500).json({
      message: error.message || "Error retrieving movie with id " + req.params.movieId
    });
  }
};

// Find shows for a specific movie
exports.findShows = async (req, res) => {
  try {
    const movieId = parseInt(req.params.movieId);
    const movie = await Movie.findOne({ movieid: movieId });

    if (!movie) {
      return res.status(404).json({
        message: `Movie not found with id ${movieId}`
      });
    }

    res.status(200).json(movie.shows);
  } catch (error) {
    res.status(500).json({
      message: error.message || "Error retrieving shows for movie id " + req.params.movieId
    });
  }
};
