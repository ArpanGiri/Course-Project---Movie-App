const express = require("express");
const router = express.Router();
const movieController = require("../controllers/movie.controller");

// GET all movies with optional filters
router.get("/", movieController.findAllMovies);

// GET a specific movie by ID
router.get("/:movieId", movieController.findOne);

// GET shows for a specific movie
router.get("/:movieId/shows", movieController.findShows);

module.exports = router;
